
   /***********************************************************************
    * Name(s) Prabir Pradhan & Claire Ma                                  *
    * Box(s): #4136         and   #3923                                   *
    * Assignment name:  Project for Module 101                            *
    * Assignment Due:  April 17,  2015                                    *
    ***********************************************************************/

   /***********************************************************************
    * Academic honesty certification:                                     *
    *   Written/online sources used:                                      *
    *     None                                                            *
    *   Help obtained:                                                    *
    *     None                                                            *
    *   My/our signature(s) below confirms that the above list of sources *
    *   is complete AND that I/we have not talked to anyone else          *
    *   (e.g., CSC 161 students) about the solution to this problem.      *
    *                                                                     *
    *                                                                     *
    *   Signature:                                      Date:             *
    *                                                                     *
    *                                                                     *
    *                                                                     *
    *   Signature:                                      Date:             *
    *                                                                     *
    ***********************************************************************/

/* music composition assistant */
#include "pitch.h"
#include "noteNode.h"
#include "noteSeq.h"
#include <stdio.h>
#include <ctype.h>  /* for character function isalpha */

/* print composer's operation menu 
   read desired menu option
   returns a lower-case letter
   input line cleared 
*/
char printAndChooseMenu ();

int main (void)
{
  /* pointer to first note of the melody */
  noteNode_t melodyFirst = NULL;

  printf ("Music composition assistant\n");

  int done = 0;
  while (!done)
    {
      char option = printAndChooseMenu();
      //char tune;
      switch (option)
        {
        case 'n':
          setNull(&melodyFirst);
          break;
        case 'a':
          addAtEnd(&melodyFirst);
          break;
        case 'c':
          changeNote(&melodyFirst);
          break;
        case 'd':
          deleteNote(&melodyFirst);
          break;
        case 'p':
          printTuneTable(melodyFirst);
          break;
        case 's':
          playTune(melodyFirst);
          break;
        case 't':
          transpose(melodyFirst);
          break;
        case 'i':
          invertMelody(melodyFirst);
          break;
        case 'q':
          printf ("program completed\n");
          return 0;
        default:
          printf ("unrecognized option\n");
        }
    }

  return 0;
}


/* print composer's operation menu 
   read desired menu option
   returns a lower-case letter
   input line cleared 
*/
char printAndChooseMenu ()
{
  printf ("menu options: \n");
  printf ("  n:  set melody to NULL\n");
  printf ("  a:  add notes to end of melody\n");
  printf ("  c:  change any note of the melody\n");
  printf ("  d:  delete any note of the melody\n");
  printf ("  p:  print table of current notes in melody\n");
  printf ("  s:  sing the melody (with scribbler robot!)\n");
  printf ("  t:  transpose by half-steps\n");
  printf ("  i:  invert the melody\n");
  printf ("  q:  quit\n");
  char ch;

  /* get menu option */
  while (!isalpha(ch = getchar()));

  /* strip remaining characters on line */
  while (getchar() != '\n');

  return tolower(ch);
}
