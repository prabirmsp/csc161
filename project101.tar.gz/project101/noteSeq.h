#ifndef _NOTESEQ_H
#define _NOTESEQ_H
#include "pitch.h"
//#include "MyroC.h"
/* list operations for a linked list of notes */

/* set list to null */
void setNull (noteNode_t * first);

/* add notes at end of a tune (a melody or musical phrase) */
void addAtEnd (noteNode_t * first);

/* change any single note */
void changeNote (noteNode_t * first);

/* delete any single note */
void deleteNote (noteNode_t * first);

/* print notes in a tune (a melody or musical phrase) in tabular form */
void printTuneTable (noteNode_t first);

/* play tune with scribbler robot */
void playTune (noteNode_t first);

/* transpose by half steps */
void transpose (noteNode_t first);

/* Inverting each note in a sequence, so that if the original 
   melody goes up a certain number of half steps, the inverted
   melody goes does the same number of half steps. */
void invertMelody(noteNode_t first);

#endif
